package com.example.tablayout;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Frag3#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Frag3 extends Fragment implements UpdateableFragment {

    ArrayList<structure_model1>inputData_3;
    public RecycleClassAdapter3 adapter3;
    RecyclerView recyclerView;
    String selectedDay;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;

    private String mParam2;

    public Frag3() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Frag3.
     */
    // TODO: Rename and change types and number of parameters
    public static Frag3 newInstance(String param1, String param2) {
        Frag3 fragment = new Frag3();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public void onDaySelected(String selectedDay) {
        // Update your fragment content based on the selected day
        updateContent(selectedDay);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            selectedDay = getArguments().getString(ARG_PARAM1);
        }

        inputData_3 = new ArrayList<>();
        updateDataBasedOnSelectedDay();
        // Initialize the adapter with your data
        adapter3 = new RecycleClassAdapter3(getContext(), inputData_3);
    }

    private void updateDataBasedOnSelectedDay() {

        if ("Day 1".equals(selectedDay)) {
            // Update data for Day 1
            inputData_3.clear();
            // Add data for Day 1
            structure_model1 datanum1 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum2 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum3 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum4 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum5 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum6 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum7 = new structure_model1("Thermal Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");

            inputData_3.add(datanum1);
            inputData_3.add(datanum2);
            inputData_3.add(datanum3);
            inputData_3.add(datanum4);
            inputData_3.add(datanum5);
            inputData_3.add(datanum6);
            inputData_3.add(datanum7);

        }

        else if ("Day 2".equals(selectedDay)) {
            // Update data for Day 2
            inputData_3.clear();
            // Add data for Day 2
            structure_model1 datanum1 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum2 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum3 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum4 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum5 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum6 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum7 = new structure_model1("Quantum Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");


            inputData_3.add(datanum1);
            inputData_3.add(datanum2);
            inputData_3.add(datanum3);
            inputData_3.add(datanum4);
            inputData_3.add(datanum5);
            inputData_3.add(datanum6);
            inputData_3.add(datanum7);
        }

        else {
            // Update data for other days

            inputData_3.clear();
            // Add data for other days
            structure_model1 datanum1 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum2 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum3 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum4 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum5 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum6 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");
            structure_model1 datanum7 = new structure_model1("High Radiation: From Theory to Application", "12:00 to 12:30", "Author: Nayan Th, Ravindra, and Souvik");


            inputData_3.add(datanum1);
            inputData_3.add(datanum2);
            inputData_3.add(datanum3);
            inputData_3.add(datanum4);
            inputData_3.add(datanum5);
            inputData_3.add(datanum6);
            inputData_3.add(datanum7);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_frag3,container,false);

        recyclerView=view.findViewById(R.id.recycleview_3);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter3);
        return view;
    }

    @Override
    public void updateContent(String day) {
        selectedDay = day;
        Log.d("Frag3", "Selected Day in updateContent: " + selectedDay);
        updateDataBasedOnSelectedDay();

        // Log the size of inputData_3 before the update
        Log.d("Frag3", "InputData_3 size before update: " + inputData_3.size());

        adapter3.notifyDataSetChanged();

        // Log the size of inputData_3 after the update
        Log.d("Frag3", "InputData_3 size after update: " + inputData_3.size());

        // Add a log statement to track Frag3 update
        Log.d("Frag3", "Frag3 content updated for Day: " + selectedDay);
    }
}