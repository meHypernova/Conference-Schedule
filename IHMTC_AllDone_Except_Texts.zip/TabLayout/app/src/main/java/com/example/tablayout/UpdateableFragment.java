package com.example.tablayout;

public interface UpdateableFragment {
    void updateContent(String day);
}

