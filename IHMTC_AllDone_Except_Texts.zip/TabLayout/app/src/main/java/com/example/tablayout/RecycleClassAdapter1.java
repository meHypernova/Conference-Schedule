package com.example.tablayout;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecycleClassAdapter1 extends RecyclerView.Adapter<RecycleClassAdapter1.ViewHolder> {

    Context context; //we want reference of context from main xml file
    static ArrayList<structure_model1>inputData_1;

    public RecycleClassAdapter1(Context context, ArrayList<structure_model1>inputData_1){
        this.context=context;
        this.inputData_1=inputData_1;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.frag1_xml_sub_xml, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.lec_title.setText(inputData_1.get(position).title);
        holder.lec_time.setText(inputData_1.get(position).time);
        holder.lec_author.setText(inputData_1.get(position).author);

        boolean isExpanded = inputData_1.get(position).isExpandable();
        holder.expandableLayout.setVisibility(isExpanded ? View.VISIBLE: View.GONE);
    }

    @Override
    public int getItemCount() {
        return inputData_1.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView lec_title, lec_author, lec_time;
        RelativeLayout tap_layout;
        RelativeLayout expandableLayout;
        public ViewHolder(View itemView){
            super(itemView);

            expandableLayout=itemView.findViewById(R.id.rl_lecture);
            lec_title=itemView.findViewById(R.id.lec_topic);
            lec_time=itemView.findViewById(R.id.lec_time);
            lec_author=itemView.findViewById(R.id.lec_author);
            tap_layout=itemView.findViewById(R.id.tap_layout);

            tap_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    structure_model1 HideTitleName=inputData_1.get(getAdapterPosition());
                    HideTitleName.setExpandable(!HideTitleName.isExpandable());
                    notifyItemChanged(getAdapterPosition());
                }
            });
        }
    }
}