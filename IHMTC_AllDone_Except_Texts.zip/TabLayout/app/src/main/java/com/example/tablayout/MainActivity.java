package com.example.tablayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.viewpager.widget.ViewPager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnDaySelectedListener {

    Spinner spinner;
    TabLayout tabLayout;
    ArrayList<String> DayList=new ArrayList<>();
    ArrayAdapter<String> SpinAdapter;
    ViewPager viewPager;
    private final MutableLiveData<String> selectedDayLiveData = new MutableLiveData<>();

    // Getter for observing the selected day
    public MutableLiveData<String> getSelectedDayLiveData() {
        return selectedDayLiveData;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout=findViewById(R.id.tablayout);
        viewPager=findViewById(R.id.viewpager);
        spinner=findViewById(R.id.spinner);

        ViewPagerMessengerAdapter adapter = new ViewPagerMessengerAdapter(getSupportFragmentManager());
        /* Read in detail how this is working */
        viewPager.setAdapter(adapter);

        //now doing tabs and viewpager synchronization to allow sliding
        tabLayout.setupWithViewPager(viewPager);

        DayList.add("Day 1");
        DayList.add("Day 2");
        DayList.add("Day 3");

        SpinAdapter=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,DayList);
        spinner.setAdapter(SpinAdapter);

        String initialSelectedDay = DayList.get(0);
        updateAllFragments(initialSelectedDay);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedDay = adapterView.getItemAtPosition(i).toString();
                onDaySelected(selectedDay);
                selectedDayLiveData.setValue(selectedDay);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //do nothing
            }
        });
    }

    @Override
    public void onDaySelected(String selectedDay) {
        updateAllFragments(selectedDay);
        viewPager.setCurrentItem(0);
    }
    private void updateAllFragments(String selectedDay) {
        // Get the current fragment position in the ViewPager
        int currentPosition = viewPager.getCurrentItem();

        // Update all fragments
        for (int i = 0; i < DayList.size(); i++) {
            // Set the current item in the ViewPager
            viewPager.setCurrentItem(i);

            // Get the currently displayed fragment
            Fragment currentFragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + viewPager.getId() + ":" + i);

            // Check if the fragment implements the UpdateableFragment interface
            if (currentFragment instanceof UpdateableFragment) {
                ((UpdateableFragment) currentFragment).updateContent(selectedDay);
            }
        }

        // Restore the original position in the ViewPager
        viewPager.setCurrentItem(currentPosition);
    }
}