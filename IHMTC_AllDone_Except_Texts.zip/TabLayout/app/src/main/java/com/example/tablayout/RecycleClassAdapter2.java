package com.example.tablayout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class RecycleClassAdapter2 extends RecyclerView.Adapter<RecycleClassAdapter2.ViewHolder>{

    Context context;
    ArrayList<structure_model1>inputData_2;
    public RecycleClassAdapter2(Context context, ArrayList<structure_model1>inputData_2){
        this.context=context;
        this.inputData_2=inputData_2;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.frag2_xml_sub_xml, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.lec_title.setText(inputData_2.get(position).title);
        holder.lec_time.setText(inputData_2.get(position).time);
        holder.lec_description.setText(inputData_2.get(position).author);

        boolean isExpandable=inputData_2.get(position).isExpandable();
        holder.expandableLayout.setVisibility(isExpandable?View.VISIBLE:View.GONE);
    }

    @Override
    public int getItemCount() {
        return inputData_2.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView lec_title, lec_time, lec_description;
        RelativeLayout tapTitle;
        RelativeLayout expandableLayout;
        public ViewHolder(View ItemView) {
            super(ItemView);

            lec_title=ItemView.findViewById(R.id.lec_topic);
            lec_time=ItemView.findViewById(R.id.lec_time);
            lec_description=ItemView.findViewById(R.id.lec_author);
            expandableLayout=ItemView.findViewById(R.id.rl_lecture);
            tapTitle=itemView.findViewById(R.id.tap_layout);

            tapTitle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    structure_model1 HideTitleName=inputData_2.get(getAdapterPosition());
                    HideTitleName.setExpandable(!HideTitleName.isExpandable());
                    notifyItemChanged(getAdapterPosition());
                }
            });
        }
    }

}
