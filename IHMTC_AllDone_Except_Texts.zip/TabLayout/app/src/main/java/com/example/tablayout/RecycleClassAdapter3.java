package com.example.tablayout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecycleClassAdapter3 extends RecyclerView.Adapter<RecycleClassAdapter3.ViewHolder> {

    Context context;
    ArrayList<structure_model1>inputData_3;

    public RecycleClassAdapter3(Context context, ArrayList<structure_model1>inputData_3){
        this.context=context;
        this.inputData_3=inputData_3;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.frag3_xml_sub_xml,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.lec_title.setText(inputData_3.get(position).title);
        holder.lec_time.setText(inputData_3.get(position).time);
        holder.lec_description.setText(inputData_3.get(position).author);

        boolean isExpandable=inputData_3.get(position).isExpandable();
        holder.expandableLayout.setVisibility(isExpandable?View.VISIBLE : View.GONE);
    }

    @Override
    public int getItemCount() {return inputData_3.size();}

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView lec_title, lec_time, lec_description;
        RelativeLayout tapTitle;
        RelativeLayout expandableLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            lec_title=itemView.findViewById(R.id.lec_topic);
            lec_time=itemView.findViewById(R.id.lec_time);
            lec_description=itemView.findViewById(R.id.lec_author);
            tapTitle=itemView.findViewById(R.id.tap_layout);
            expandableLayout=itemView.findViewById(R.id.rl_lecture);

            tapTitle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    structure_model1 HideTitleName=inputData_3.get(getAdapterPosition());
                    HideTitleName.setExpandable(!HideTitleName.isExpandable());
                    notifyItemChanged(getAdapterPosition());
                }
            });
        }
    }
}
