package com.example.tablayout;

public interface  OnDaySelectedListener {
    void onDaySelected(String selectedDay);
}
