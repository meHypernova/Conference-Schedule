package com.example.tablayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class ViewPagerMessengerAdapter extends FragmentPagerAdapter {
    public ViewPagerMessengerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (position == 0) return new Frag1();
        else if(position==1) return new Frag2();
        else return new Frag3();
    }


    @Override
    public int getCount() {
        return 3; //number of tabs
    }

    //this function will make the title, it get position and returns charsequence(ie String)
    //CharSequence ie 0th index pe kya title(name of title) etc
    @Override
    public CharSequence getPageTitle(int position) {
        if(position==0) return "SESSION 1";
        else if(position==1) return "SESSION 2";
        else  return "SESSION 3";
    }
}
