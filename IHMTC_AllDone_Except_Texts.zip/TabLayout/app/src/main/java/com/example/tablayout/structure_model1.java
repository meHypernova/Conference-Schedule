package com.example.tablayout;

public class structure_model1 {
    String title,time, author;
    boolean expandable;

    public structure_model1(String title, String time, String author){
        this.title=title;
        this.time=time;
        this.author=author;
        this.expandable=false;
    }

    public boolean isExpandable() {
        return expandable;
    }

    public void setExpandable(boolean expandable) {
        this.expandable = expandable;
    }
}
